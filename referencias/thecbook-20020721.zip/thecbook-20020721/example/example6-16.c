struct s {
  int a;
  struct ss {
    int c;
    char d;
  } e;
} x[] = {
	 1, 2, 'a',
	 3, 4, 'b'
};
