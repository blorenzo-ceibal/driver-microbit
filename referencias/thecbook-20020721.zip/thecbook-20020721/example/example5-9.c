#define ARLEN 10

int ar[ARLEN], *ip;

ip = ar;
while (ip < &ar[ARLEN])
  *(ip++) = 0;
