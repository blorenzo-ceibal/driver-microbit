main() {
  double return_v, aax1(void);
  return_v = aax1();
  exit(EXIT_SUCCESS);
}
