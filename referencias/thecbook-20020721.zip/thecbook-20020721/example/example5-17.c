void (*fparr[])(int, float) = {
			       /* initializers */
};
/* then call one */

fparr[5](1, 3.4);
